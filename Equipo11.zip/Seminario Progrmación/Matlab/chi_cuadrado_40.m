grados_libertad = 10;
datos_chi_cuadrado = chi2rnd(grados_libertad, 1, 40);
disp(datos_chi_cuadrado);
