%    Esta genera una distribucion normal de valores entre 0 y 100
%    La media y la desviacion estandar pueden variar segun las necesidades de
%    uno

media=50;
desviacion_estandar=15;
datos_normalizados2=normrnd(media,desviacion_estandar,1,4000)
datos_normalizados2(datos_normalizados2<0)=0;
datos_normalizados2(datos_normalizados2>100)=100;
