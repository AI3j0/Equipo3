lambda_poisson = 10;
datos_poisson = poissrnd(lambda_poisson,1,40);
disp(datos_poisson);
