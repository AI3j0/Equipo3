lambda_poisson = 50;
datos_poisson2 = poissrnd(lambda_poisson,1,4000);
disp(datos_poisson2);