grados_libertad = 30;
datos_chi_cuadrado2 = chi2rnd(grados_libertad, 1, 4000);
disp(datos_chi_cuadrado2);