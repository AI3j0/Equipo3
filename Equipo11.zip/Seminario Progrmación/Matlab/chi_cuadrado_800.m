grados_libertad = 20;
datos_chi_cuadrado1 = chi2rnd(grados_libertad, 1, 800);
disp(datos_chi_cuadrado1);