#include<iostream>
#include<conio.h>
#include<fstream>
#include<vector>
#include<chrono>

using namespace std;
using namespace std::chrono;

double dato=0;

int contador=0;
void cargar();
void selection_sort(vector<double>&);
void shell_sort(vector<double>&);
int main(){
	for(int i=0;i<12;i++){
	
	cargar();

}
	
	getch();
	return 0;
}

void cargar(){

	vector<double> datos;
	int i=0;
	while(i<1){
		if(contador==0){
			ifstream archivo("juego0001.txt");
				while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==1){
			ifstream archivo("juego0010.txt");
				while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==2){
				ifstream archivo("juego0011.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==3){
				ifstream	archivo("juego0100.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==4){
				ifstream	archivo("juego0101.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==5){
				ifstream	archivo("juego0110.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==6){
				ifstream	archivo("juego0111.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==7){
				ifstream	archivo("juego1000.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
	
	
	
		}else if(contador==8){
				ifstream	archivo("juego1001.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==9){
				ifstream	archivo("juego1010.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==10){
				ifstream	archivo("juego1011.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		}else if(contador==11){
				ifstream	archivo("juego1100.txt");
					while(archivo>>dato){
		datos.push_back(dato);
	}
		
		}
		i++;
		contador++;
	
}
	std::cout<<endl<<"Antes de ordenar: "<<endl<<endl;
	for(int i=0;i<datos.size();i++){
		std::cout<<datos[i]<<" ";}
	selection_sort(datos);
	shell_sort(datos);
	
	datos.clear();
    
	
}

void selection_sort(vector<double>& datos){
	high_resolution_clock::time_point t0,t1;
     unsigned long long t=0;
     t0=high_resolution_clock::now();
	
	for(int i=0;i<datos.size()-1;i++){
		
		int maxp=0;
		for(int k=1;k<datos.size()-1-i;k++){
			if(datos[k]>datos[maxp]){
				maxp=k;
			}
		}
		    if(maxp!=datos.size()-1-i){
		    	double temp=datos[maxp];
		    	datos[maxp]=datos[datos.size()-1-i];
		    	datos[datos.size()-1-i]=temp;
			}
			
	}
     	
	t1=high_resolution_clock::now();
	std::cout<<endl<<"\n\n\n\n\n Despues de ordenar Selection Sort: \n\n"<<endl;
	for(int i=0;i<datos.size();i++){
		std::cout<<datos[i]<<" ";
	}
	   
  t+=high_resolution_clock::duration(t1-t0).count();
  
	
	

	
	std::cout<<"\n\n\n\n\n\nEl tiempo del ordenamineto Seleccion Sort es "<<t<<endl;
}
void shell_sort(vector<double>& datos){
	
		high_resolution_clock::time_point t0,t1;
     unsigned long long  mt=0;
     t0=high_resolution_clock::now();  
	//Shell Sort
	for(int gap=datos.size()/2;gap>0;gap/=2){
		for(int i=gap;i<datos.size();i++){
			double temp=datos[i];
			int j=i;
			for(j;j>=gap && datos[j-gap]>temp;j-=gap){
				datos[j]=datos[j-gap];
			}
			datos[j]=temp;
		}
	}
	t1=high_resolution_clock::now();
	std::cout << endl << "\n\n\n\n\n Despues de ordenar Shell Sort: \n\n" << endl;
    for(int i = 0; i < datos.size(); i++) {
        std::cout << datos[i] << " ";
    }
	   
	mt +=high_resolution_clock::duration(t1-t0).count();
	
	

	
	
	std::cout<<"\n\n\n\n\n\nEl tiempo del ordenamineto Shell Sort es "<<mt<<endl;

	
}